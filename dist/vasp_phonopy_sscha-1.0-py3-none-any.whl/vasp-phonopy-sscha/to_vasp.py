def to_vasp():
    path = "data/position/"
    return path

